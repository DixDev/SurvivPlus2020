# Soy DixDev, como muchos ya sabr�n
Planeo mejorar la extensi�n agregando nuevas funciones, como mostrar los nombres de los jugadores y un temporizador de "Fragmentadores" o "Granadas"
