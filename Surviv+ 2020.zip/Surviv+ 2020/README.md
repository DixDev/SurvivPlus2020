# Suriv+ 2020

## ~~ Esta extensi�n est� a�n en modo desarrollo, por favor, pru�bala bajo tus propios riesgos ~~
## ~~ This extension is still in development mode, please try it at your own risk ~~

Contin�a observando su desarrollo: [maintenance_notice.md](maintenance_notice.md).

Nuevas caracter�sticas para Suviv.io:
New Surviv.io features:

- Aimbot2020 (Autoapuntar) sin errores, al enemigo m�s cercano y con una predicci�n de 23 ms
- Muestra la ubicaci�n del enemigo
- Colorea la l�nea del enemigo en amarillo cuando est� cerca y rojo cuando le puedas disparar
- Colorea tambi�n las l�neas de los enemigos que est�n en subterr�neos
- Te muestra d�nde est�n art�culos de protecci�n (cascos, chalecos) y tambi�n las miras (o mirillas) (x1, x2, x4, x8, x15)
- Hace transparente �rboles, mesas, macetas y techos de casas para que no se te esconda nadie
- Colorea de rojo y aumenta de tama�o las granadas para aumentar tu atenci�n
- Aumenta el tama�o del mapa y te muestra la ubicaci�n de objetos especiales

# No se planea subirla a Chrome Web Store - There is no planned to upload it to Chrome Web Store

Saludos desde ecuador!
DixDev

