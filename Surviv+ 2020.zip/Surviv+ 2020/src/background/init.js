{
    window.bgapp = {};
}
